# Contributing to All Types of OSINT

We welcome contributions! To contribute:
1. Fork the repo.
2. Create a new branch.
3. Add your tool or script.
4. Submit a pull request.

Please ensure all tools added are legitimate and useful for OSINT investigations.
