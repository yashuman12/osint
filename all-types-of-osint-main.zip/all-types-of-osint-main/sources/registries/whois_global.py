import asyncio
import socket

REGIONAL_WHOIS = {
    "ARIN":    "whois.arin.net",    # North America
    "RIPE":    "whois.ripe.net",    # Europe / Middle East
    "APNIC":   "whois.apnic.net",   # Asia-Pacific
    "LACNIC":  "whois.lacnic.net",  # Latin America
    "AFRINIC": "whois.afrinic.net", # Africa
}

async def query_whois(target: str, server: str):
    try:
        reader, writer = await asyncio.open_connection(server, 43)
        writer.write(f"{target}\r\n".encode())
        await writer.drain()
        
        response = b""
        while True:
            data = await reader.read(4096)
            if not data:
                break
            response += data
        
        writer.close()
        await writer.wait_closed()
        return {"server": server, "response": response.decode(errors='ignore')}
    except Exception as e:
        return {"server": server, "error": str(e)}

def route_to_registry(ip: str) -> str:
    """Return the most likely authoritative WHOIS server for this IP."""
    try:
        first_octet = int(ip.split(".")[0])
    except:
        return "ARIN"
    # Very rough routing by first octet (real tools use IANA ranges)
    if first_octet in range(1, 128):
        return "ARIN"    # North America (many legacy blocks)
    elif first_octet in range(128, 192):
        return "RIPE"    # Europe / Middle East
    elif first_octet in range(192, 224):
        return "APNIC"   # Asia-Pacific
    return "ARIN"        # fallback

async def global_ip_lookup(ip: str):
    primary = route_to_registry(ip)
    # Query primary first, then fall back to all if no useful result
    primary_result = await query_whois(ip, REGIONAL_WHOIS[primary])
    if "No entries found" not in primary_result.get("response", "No entries found") and "error" not in primary_result:
        return [primary_result]  # Fast path: found it
    # Slow path: query all registries
    tasks = [query_whois(ip, srv) for srv in REGIONAL_WHOIS.values()]
    return await asyncio.gather(*tasks)

if __name__ == "__main__":
    import json
    import sys
    ip = sys.argv[1] if len(sys.argv) > 1 else "8.8.8.8"
    loop = asyncio.get_event_loop()
    results = loop.run_until_complete(global_ip_lookup(ip))
    print(json.dumps(results))
