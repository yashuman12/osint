# Legal & Ethical Use of OSINT

1. **Compliance**: Always comply with local and international laws.
2. **Privacy**: Respect individual privacy. Do not use OSINT for harassment or stalking.
3. **Authorization**: Ensure you have permission for any active scanning or penetration testing.
4. **Attribution**: Be aware of how your activities might be attributed back to you.
