# OSINT Investigation Guide

## Phase 1: Preparation
- Define the objective.
- Set up a secure environment (VPN, VM, Sock Puppets).

## Phase 2: Collection
- Use automated tools (SpiderFoot, Recon-ng).
- Manual search across categories.

## Phase 3: Analysis
- Correlate data points.
- Verify findings through multiple sources.

## Phase 4: Reporting
- Document the process.
- Present evidence clearly.
