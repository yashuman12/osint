import React, { useState, useEffect } from 'react';
import { Search, Shield, ExternalLink, Copy, Check, Terminal, FileText, Database, Lock, AlertTriangle, Layers, Server } from 'lucide-react';

interface DorkItem {
  id?: string;
  title: string;
  query: string;
  description?: string;
  purpose?: string;
  category?: string;
  categoryLabel?: string;
  severity?: string;
  riskColor?: string;
  googleSearchUrl: string;
}

interface TargetCategory {
  category: string;
  dorks: DorkItem[];
}

export function GHDBPanel({ initialTarget }: { initialTarget?: string }) {
  const [activeTab, setActiveTab] = useState<'generator' | 'catalog'>('generator');
  const [targetDomain, setTargetDomain] = useState(initialTarget || '');
  const [targetDorks, setTargetDorks] = useState<TargetCategory[]>([]);
  const [loadingTarget, setLoadingTarget] = useState(false);
  
  // Catalog state
  const [catalogDorks, setCatalogDorks] = useState<DorkItem[]>([]);
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [loadingCatalog, setLoadingCatalog] = useState(false);

  const [copiedQuery, setCopiedQuery] = useState<string | null>(null);

  useEffect(() => {
    if (initialTarget && initialTarget.trim().length > 0) {
      setTargetDomain(initialTarget);
      fetchTargetDorks(initialTarget);
    } else {
      setTargetDomain('example.com');
      fetchTargetDorks('example.com');
    }
    fetchCatalog();
  }, []);

  const fetchTargetDorks = async (target: string) => {
    if (!target) return;
    setLoadingTarget(true);
    try {
      const res = await fetch(`/api/osint/dorks/${encodeURIComponent(target)}`);
      if (res.ok) {
        const data = await res.json();
        setTargetDorks(data.categories || []);
      }
    } catch (err) {
      console.error('Failed to fetch target dorks:', err);
    } finally {
      setLoadingTarget(false);
    }
  };

  const fetchCatalog = async (cat = selectedCategory, q = searchQuery) => {
    setLoadingCatalog(true);
    try {
      const params = new URLSearchParams();
      if (cat && cat !== 'all') params.append('category', cat);
      if (q) params.append('q', q);

      const res = await fetch(`/api/osint/ghdb?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setCatalogDorks(data.dorks || []);
        if (data.categories) setCategories(data.categories);
      }
    } catch (err) {
      console.error('Failed to fetch GHDB catalog:', err);
    } finally {
      setLoadingCatalog(false);
    }
  };

  const handleCopy = (query: string) => {
    navigator.clipboard.writeText(query);
    setCopiedQuery(query);
    setTimeout(() => setCopiedQuery(null), 2000);
  };

  const handleTargetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (targetDomain.trim()) {
      fetchTargetDorks(targetDomain.trim());
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-red-950/40 via-black/60 to-black/40 border border-red-500/30 p-6 rounded-lg relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Terminal size={140} className="text-red-500" />
        </div>
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-red-500/20 border border-red-500/50 rounded text-red-400">
            <Shield size={22} />
          </div>
          <div>
            <h2 className="font-mono text-xl font-bold text-white tracking-tight flex items-center gap-2">
              Google Hacking Database (GHDB) Suite
              <span className="text-[10px] bg-red-500/20 text-red-400 border border-red-500/40 px-2 py-0.5 rounded font-mono uppercase">
                Exploit-DB Intelligence
              </span>
            </h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Automated Google Dork reconnaissance for target footprinting, credential leaks, directory indexing, and exposed cloud storage.
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-2 mt-6 border-b border-white/10 pb-2">
          <button
            onClick={() => setActiveTab('generator')}
            className={`px-4 py-2 rounded text-xs font-mono font-bold transition-all flex items-center gap-2 ${
              activeTab === 'generator'
                ? 'bg-red-500/20 text-red-400 border border-red-500/50 shadow-[0_0_12px_rgba(239,68,68,0.2)]'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <TargetIcon size={14} />
            Target Dork Generator
          </button>
          <button
            onClick={() => {
              setActiveTab('catalog');
              fetchCatalog();
            }}
            className={`px-4 py-2 rounded text-xs font-mono font-bold transition-all flex items-center gap-2 ${
              activeTab === 'catalog'
                ? 'bg-red-500/20 text-red-400 border border-red-500/50 shadow-[0_0_12px_rgba(239,68,68,0.2)]'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Database size={14} />
            GHDB Dork Library Catalog
          </button>
        </div>
      </div>

      {/* TAB 1: Target Dork Generator */}
      {activeTab === 'generator' && (
        <div className="space-y-6">
          <form onSubmit={handleTargetSubmit} className="flex gap-3 bg-black/40 border border-osint-border p-4 rounded-lg">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
              <input
                type="text"
                placeholder="Enter target domain or company name (e.g. tesla.com, target.org)..."
                value={targetDomain}
                onChange={(e) => setTargetDomain(e.target.value)}
                className="w-full bg-black/60 border border-osint-border rounded py-2.5 pl-10 pr-4 font-mono text-sm text-white focus:outline-none focus:border-red-500/50"
              />
            </div>
            <button
              type="submit"
              disabled={loadingTarget}
              className="bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/40 px-6 py-2.5 rounded font-mono text-xs font-bold transition-all flex items-center gap-2"
            >
              {loadingTarget ? (
                <div className="w-4 h-4 border-2 border-red-400 border-t-transparent rounded-full animate-spin" />
              ) : (
                <Shield size={14} />
              )}
              Generate Recon Dorks
            </button>
          </form>

          {loadingTarget ? (
            <div className="p-12 text-center bg-black/20 border border-osint-border rounded-lg">
              <div className="w-8 h-8 border-2 border-red-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <p className="font-mono text-xs text-slate-400">Synthesizing Google Dorks for target domain...</p>
            </div>
          ) : targetDorks.length === 0 ? (
            <div className="p-8 text-center bg-black/20 border border-osint-border rounded-lg text-slate-500 font-mono text-xs">
              Enter a target domain above to generate customized reconnaissance dorks.
            </div>
          ) : (
            <div className="space-y-6">
              {targetDorks.map((cat, idx) => (
                <div key={idx} className="bg-black/40 border border-osint-border rounded-lg p-5 space-y-4">
                  <h3 className="font-mono text-sm font-bold text-red-400 uppercase tracking-wider flex items-center gap-2 border-b border-osint-border pb-3">
                    <AlertTriangle size={16} />
                    {cat.category}
                    <span className="ml-auto text-[10px] text-slate-500 font-normal">
                      {cat.dorks.length} queries
                    </span>
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {cat.dorks.map((dork, dIdx) => (
                      <div
                        key={dIdx}
                        className="bg-black/60 border border-white/5 hover:border-red-500/30 rounded p-4 flex flex-col justify-between transition-all group"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-mono text-xs font-bold text-white group-hover:text-red-400 transition-colors">
                              {dork.title}
                            </h4>
                          </div>

                          <p className="text-[11px] text-slate-400 font-sans mb-3 line-clamp-2">
                            {dork.purpose}
                          </p>

                          <div className="bg-black/80 p-2.5 rounded border border-white/10 font-mono text-[11px] text-green-400 break-all select-all mb-3">
                            {dork.query}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                          <button
                            onClick={() => handleCopy(dork.query)}
                            className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-1.5 px-3 rounded text-[11px] font-mono flex items-center justify-center gap-1.5 transition-colors"
                          >
                            {copiedQuery === dork.query ? (
                              <>
                                <Check size={12} className="text-green-400" />
                                Copied!
                              </>
                            ) : (
                              <>
                                <Copy size={12} />
                                Copy Dork
                              </>
                            )}
                          </button>

                          <a
                            href={dork.googleSearchUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 py-1.5 px-3 rounded text-[11px] font-mono font-bold flex items-center justify-center gap-1.5 transition-all"
                          >
                            <ExternalLink size={12} />
                            Launch Google
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: GHDB Library Catalog */}
      {activeTab === 'catalog' && (
        <div className="space-y-6">
          {/* Controls */}
          <div className="flex flex-col md:flex-row gap-4 bg-black/40 border border-osint-border p-4 rounded-lg">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
              <input
                type="text"
                placeholder="Search GHDB catalog by title, query, or keyword..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  fetchCatalog(selectedCategory, e.target.value);
                }}
                className="w-full bg-black/60 border border-osint-border rounded py-2 pl-10 pr-4 font-mono text-xs text-white focus:outline-none focus:border-red-500/50"
              />
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    fetchCatalog(cat.id, searchQuery);
                  }}
                  className={`px-3 py-1.5 rounded text-[11px] font-mono whitespace-nowrap transition-all ${
                    selectedCategory === cat.id
                      ? 'bg-red-500/20 text-red-400 border border-red-500/40 font-bold'
                      : 'bg-white/5 text-slate-400 hover:text-white border border-white/5'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Dork Library Items Grid */}
          {loadingCatalog ? (
            <div className="p-12 text-center bg-black/20 border border-osint-border rounded-lg">
              <div className="w-8 h-8 border-2 border-red-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <p className="font-mono text-xs text-slate-400">Fetching GHDB catalog entries...</p>
            </div>
          ) : catalogDorks.length === 0 ? (
            <div className="p-8 text-center bg-black/20 border border-osint-border rounded-lg text-slate-500 font-mono text-xs">
              No GHDB catalog items found for the selected category or search filter.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {catalogDorks.map((item) => (
                <div
                  key={item.id}
                  className="bg-black/40 border border-osint-border hover:border-red-500/40 rounded-lg p-5 flex flex-col justify-between transition-all group"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 px-2 py-0.5 rounded bg-white/5 border border-white/10">
                        {item.categoryLabel || item.category}
                      </span>
                      {item.severity && (
                        <span
                          className="text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase border"
                          style={{
                            color: item.riskColor || '#ef4444',
                            backgroundColor: `${item.riskColor || '#ef4444'}15`,
                            borderColor: `${item.riskColor || '#ef4444'}40`,
                          }}
                        >
                          {item.severity}
                        </span>
                      )}
                    </div>

                    <h4 className="font-mono text-sm font-bold text-white group-hover:text-red-400 transition-colors mb-2">
                      {item.title}
                    </h4>

                    <p className="text-xs text-slate-400 mb-3">
                      {item.description}
                    </p>

                    <div className="bg-black/80 p-3 rounded border border-white/10 font-mono text-xs text-green-400 break-all select-all mb-4">
                      {item.query}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-3 border-t border-osint-border">
                    <button
                      onClick={() => handleCopy(item.query)}
                      className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-1.5 px-3 rounded text-xs font-mono flex items-center justify-center gap-1.5 transition-colors"
                    >
                      {copiedQuery === item.query ? (
                        <>
                          <Check size={14} className="text-green-400" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy size={14} />
                          Copy Query
                        </>
                      )}
                    </button>

                    <a
                      href={item.googleSearchUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 py-1.5 px-3 rounded text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all"
                    >
                      <ExternalLink size={14} />
                      Run Google Dork
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function TargetIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="6" />
      <circle cx="12" cy="12" r="2" />
    </svg>
  );
}
