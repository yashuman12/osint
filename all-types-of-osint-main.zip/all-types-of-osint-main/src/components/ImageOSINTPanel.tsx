import React, { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, Search, ExternalLink, Shield, Copy, Check, MapPin, Camera, AlertTriangle, FileText, Globe, RefreshCw, Lock } from 'lucide-react';
import Markdown from 'react-markdown';

interface ImageOSINTPanelProps {
  initialFile?: { name: string; data: string; type: string } | null;
  onFileSelect?: (file: { name: string; data: string; type: string } | null) => void;
  onLog?: (msg: string) => void;
}

export function ImageOSINTPanel({ initialFile, onFileSelect, onLog }: ImageOSINTPanelProps) {
  const [selectedFile, setSelectedFile] = useState<{ name: string; data: string; type: string; rawBlob?: Blob } | null>(
    initialFile ? { ...initialFile } : null
  );
  const [imageUrl, setImageUrl] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [results, setResults] = useState<any | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    setError(null);
    const reader = new FileReader();
    reader.onloadend = () => {
      const fileData = {
        name: file.name,
        data: reader.result as string,
        type: file.type,
        rawBlob: file
      };
      setSelectedFile(fileData);
      setImageUrl('');
      if (onFileSelect) onFileSelect(fileData);
      if (onLog) onLog(`Image loaded: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        processFile(file);
      } else {
        setError('Please drop a valid image file (JPEG, PNG, WEBP, TIFF).');
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const executeImageSearch = async () => {
    if (!selectedFile && !imageUrl) {
      setError('Please upload an image file or enter an image URL to analyze.');
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    setResults(null);
    setAiAnalysis(null);

    if (onLog) onLog(`Executing Image OSINT analysis...`);

    try {
      const formData = new FormData();
      if (selectedFile) {
        if (selectedFile.rawBlob) {
          formData.append('image', selectedFile.rawBlob, selectedFile.name);
        } else {
          const res = await fetch(selectedFile.data);
          const blob = await res.blob();
          formData.append('image', blob, selectedFile.name);
        }
      } else if (imageUrl) {
        formData.append('imageUrl', imageUrl);
      }

      // 1. Call backend Image OSINT API
      const apiRes = await fetch('/api/osint/image', {
        method: 'POST',
        body: formData
      });

      if (!apiRes.ok) {
        const errData = await apiRes.json().catch(() => ({}));
        throw new Error(errData.error || 'Server returned error during image scan.');
      }

      const data = await apiRes.json();
      setResults(data);
      if (onLog) onLog(`Image scan complete. EXIF: ${data.hasExif ? 'Found' : 'None'}. Links generated.`);

      // 2. Query Gemini AI Analyst for visual OSINT analysis
      try {
        if (onLog) onLog('Synthesizing visual intelligence with Gemini AI...');
        const aiRes = await fetch('/api/ai/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            query: `Analyze this image for OSINT metadata, location clues, text OCR, landmarks, camera signatures, and potential security risks.`,
            data: data,
            imageData: selectedFile ? selectedFile.data : null
          })
        });

        if (aiRes.ok) {
          const aiData = await aiRes.json();
          setAiAnalysis(aiData.analysis || aiData.result);
        }
      } catch (aiErr) {
        console.warn('AI analysis fallback:', aiErr);
      }

    } catch (err: any) {
      console.error('Image OSINT error:', err);
      setError(err.message || 'Failed to complete image search.');
      if (onLog) onLog(`Error: ${err.message}`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLink(text);
    setTimeout(() => setCopiedLink(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-950/40 via-black/60 to-black/40 border border-blue-500/30 p-6 rounded-lg relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <ImageIcon size={140} className="text-blue-400" />
        </div>
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-blue-500/20 border border-blue-500/50 rounded text-blue-400">
            <Camera size={22} />
          </div>
          <div>
            <h2 className="font-mono text-xl font-bold text-white tracking-tight flex items-center gap-2">
              Image OSINT & Forensic Analysis Engine
              <span className="text-[10px] bg-blue-500/20 text-blue-400 border border-blue-500/40 px-2 py-0.5 rounded font-mono uppercase">
                Reverse Image + EXIF
              </span>
            </h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Extract camera EXIF metadata, GPS geotags, cryptographic hashes, and query multi-engine reverse image search databases (Google Lens, Yandex, TinEye, Bing).
            </p>
          </div>
        </div>
      </div>

      {/* Upload & Source Selection Card */}
      <div className="bg-black/40 border border-osint-border p-6 rounded-lg space-y-4">
        <h3 className="font-mono text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <Upload size={14} className="text-blue-400" />
          Select Target Image Evidence
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* File Drag and Drop Zone */}
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center min-h-[180px] ${
              selectedFile
                ? 'border-blue-500/50 bg-blue-500/10'
                : 'border-white/10 hover:border-blue-500/30 bg-black/40 hover:bg-white/5'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />

            {selectedFile ? (
              <div className="space-y-3">
                <img
                  src={selectedFile.data}
                  alt="Preview"
                  className="w-24 h-24 object-cover rounded border border-blue-500/50 mx-auto shadow-md"
                />
                <div>
                  <p className="font-mono text-xs font-bold text-white truncate max-w-[220px]">
                    {selectedFile.name}
                  </p>
                  <p className="font-mono text-[10px] text-slate-400">
                    {selectedFile.type || 'Image File'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedFile(null);
                    if (onFileSelect) onFileSelect(null);
                  }}
                  className="text-[10px] font-mono text-red-400 hover:text-red-300 underline"
                >
                  Remove Image
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="p-3 bg-white/5 rounded-full w-12 h-12 flex items-center justify-center mx-auto text-slate-400">
                  <Upload size={20} />
                </div>
                <div>
                  <p className="font-mono text-xs text-white font-bold">
                    Click or Drag & Drop Image Here
                  </p>
                  <p className="font-mono text-[10px] text-slate-500 mt-1">
                    Supports JPEG, PNG, WEBP, TIFF image formats
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Image URL Input Option */}
          <div className="bg-black/60 border border-white/10 rounded-lg p-5 flex flex-col justify-between">
            <div className="space-y-3">
              <label className="font-mono text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Globe size={14} className="text-blue-400" />
                Or Enter Public Image URL
              </label>
              <input
                type="url"
                placeholder="https://example.com/target-image.jpg"
                value={imageUrl}
                onChange={(e) => {
                  setImageUrl(e.target.value);
                  if (e.target.value) setSelectedFile(null);
                }}
                className="w-full bg-black/80 border border-osint-border rounded py-2 px-3 font-mono text-xs text-white focus:outline-none focus:border-blue-500/50"
              />
              <p className="text-[11px] text-slate-500">
                Directly fetches external hosted images for metadata inspection and reverse engine lookups.
              </p>
            </div>

            {/* Execute Button */}
            <div className="pt-4">
              <button
                type="button"
                onClick={executeImageSearch}
                disabled={isAnalyzing || (!selectedFile && !imageUrl)}
                className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-mono text-xs font-bold py-3 px-4 rounded transition-all flex items-center justify-center gap-2 shadow-lg"
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCw size={14} className="animate-spin" />
                    Executing Forensic Scan...
                  </>
                ) : (
                  <>
                    <Search size={14} />
                    EXECUTE IMAGE OSINT SEARCH
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/30 rounded text-red-400 font-mono text-xs flex items-center gap-2">
            <AlertTriangle size={14} />
            {error}
          </div>
        )}
      </div>

      {/* Analysis Results */}
      {results && (
        <div className="space-y-6">
          {/* File Info Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-black/40 border border-osint-border rounded-lg">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">File Name</span>
              <span className="text-xs font-mono text-white font-bold truncate block mt-1">
                {results.fileInfo?.name || 'Uploaded Image'}
              </span>
            </div>
            <div className="p-4 bg-black/40 border border-osint-border rounded-lg">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">File Size</span>
              <span className="text-xs font-mono text-blue-400 font-bold block mt-1">
                {results.fileInfo?.size || 'N/A'}
              </span>
            </div>
            <div className="p-4 bg-black/40 border border-osint-border rounded-lg">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">MIME Type</span>
              <span className="text-xs font-mono text-slate-300 block mt-1">
                {results.fileInfo?.type || 'N/A'}
              </span>
            </div>
            <div className="p-4 bg-black/40 border border-osint-border rounded-lg">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">SHA-256 Hash</span>
              <span className="text-[10px] font-mono text-green-400 truncate block mt-1" title={results.sha256}>
                {results.sha256 ? `${results.sha256.substring(0, 16)}...` : 'N/A'}
              </span>
            </div>
          </div>

          {/* Reverse Search Links Box */}
          <div className="bg-black/40 border border-osint-border rounded-lg p-5 space-y-4">
            <h3 className="font-mono text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Globe size={14} className="text-blue-400" />
              Reverse Image Search Database Launchers
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {results.reverseSearchLinks?.google && (
                <a
                  href={results.reverseSearchLinks.google}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-white/5 hover:bg-blue-500/20 border border-white/10 hover:border-blue-500/40 rounded flex items-center justify-between text-xs font-mono text-slate-200 hover:text-blue-400 transition-all"
                >
                  <span className="font-bold flex items-center gap-1.5">
                    Google Lens
                  </span>
                  <ExternalLink size={14} />
                </a>
              )}

              {results.reverseSearchLinks?.yandex && (
                <a
                  href={results.reverseSearchLinks.yandex}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-white/5 hover:bg-red-500/20 border border-white/10 hover:border-red-500/40 rounded flex items-center justify-between text-xs font-mono text-slate-200 hover:text-red-400 transition-all"
                >
                  <span className="font-bold flex items-center gap-1.5">
                    Yandex Images
                  </span>
                  <ExternalLink size={14} />
                </a>
              )}

              {results.reverseSearchLinks?.tineye && (
                <a
                  href={results.reverseSearchLinks.tineye}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-white/5 hover:bg-yellow-500/20 border border-white/10 hover:border-yellow-500/40 rounded flex items-center justify-between text-xs font-mono text-slate-200 hover:text-yellow-400 transition-all"
                >
                  <span className="font-bold flex items-center gap-1.5">
                    TinEye Search
                  </span>
                  <ExternalLink size={14} />
                </a>
              )}

              {results.reverseSearchLinks?.bing && (
                <a
                  href={results.reverseSearchLinks.bing}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-white/5 hover:bg-teal-500/20 border border-white/10 hover:border-teal-500/40 rounded flex items-center justify-between text-xs font-mono text-slate-200 hover:text-teal-400 transition-all"
                >
                  <span className="font-bold flex items-center gap-1.5">
                    Bing Visual
                  </span>
                  <ExternalLink size={14} />
                </a>
              )}
            </div>
          </div>

          {/* EXIF Metadata Card */}
          <div className="bg-black/40 border border-osint-border rounded-lg p-5 space-y-4">
            <h3 className="font-mono text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Camera size={14} className="text-blue-400" />
              Camera EXIF & Device Forensics
            </h3>

            {results.hasExif ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 bg-black/60 p-4 rounded border border-white/5 font-mono text-xs">
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-500">Camera Make:</span>
                    <span className="text-white font-bold">{results.deviceInfo?.make || 'Unknown'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-500">Camera Model:</span>
                    <span className="text-white font-bold">{results.deviceInfo?.model || 'Unknown'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-500">Software:</span>
                    <span className="text-slate-300">{results.deviceInfo?.software || 'Unknown'}</span>
                  </div>
                </div>

                <div className="space-y-2 bg-black/60 p-4 rounded border border-white/5 font-mono text-xs">
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-500">Date Taken:</span>
                    <span className="text-white font-bold">{results.deviceInfo?.dateTaken || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-500">Date Modified:</span>
                    <span className="text-slate-300">{results.deviceInfo?.dateModified || 'N/A'}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-black/60 rounded border border-white/5 text-slate-500 font-mono text-xs">
                No embedded EXIF metadata detected in image (file may have been stripped by web optimizer or screenshot).
              </div>
            )}

            {/* GPS Geolocation if available */}
            {results.geolocation && (
              <div className="bg-green-500/10 border border-green-500/30 p-4 rounded-lg space-y-3">
                <div className="flex items-center gap-2 text-green-400 font-mono text-xs font-bold">
                  <MapPin size={16} />
                  GPS Geolocation Tag Found in EXIF
                </div>
                <p className="font-mono text-xs text-slate-300">
                  Latitude: <span className="font-bold text-white">{results.geolocation.lat}</span> | Longitude: <span className="font-bold text-white">{results.geolocation.lng}</span>
                </p>
                <div className="flex gap-3">
                  <a
                    href={results.geolocation.mapLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-green-600 hover:bg-green-500 text-black font-mono text-xs font-bold px-3 py-1.5 rounded flex items-center gap-1.5"
                  >
                    Open Google Maps <ExternalLink size={12} />
                  </a>
                  <a
                    href={results.geolocation.osmLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-white/10 hover:bg-white/20 text-white font-mono text-xs px-3 py-1.5 rounded flex items-center gap-1.5"
                  >
                    OpenStreetMap <ExternalLink size={12} />
                  </a>
                </div>
              </div>
            )}
          </div>

          {/* AI Visual Intelligence Analysis */}
          {aiAnalysis && (
            <div className="bg-black/40 border border-osint-border rounded-lg p-5 space-y-3">
              <h3 className="font-mono text-xs font-bold text-blue-400 uppercase tracking-wider flex items-center gap-2">
                <Shield size={14} />
                Gemini AI Forensic Synthesis
              </h3>
              <div className="prose prose-invert max-w-none font-mono text-xs text-slate-300 leading-relaxed bg-black/60 p-4 rounded border border-white/5">
                <Markdown>{aiAnalysis}</Markdown>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
