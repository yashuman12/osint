import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const osintAnalyst = async (query: string, data: any, fileData?: { data: string, mimeType: string }) => {
  const parts: any[] = [
    {
      text: `Analyze the following OSINT data for the query "${query}". 
    
    The data includes both web search results and real-time API data from sources like Shodan, Hunter.io, and VirusTotal.
    
    Identify:
    1. Potential security vulnerabilities or exposed services.
    2. Data leaks, breaches, or sensitive information exposure.
    3. Infrastructure details (IPs, domains, hosting providers).
    4. Social media footprint and identity correlation.
    5. Overall risk assessment.
    
    Format the report using clear Markdown headers and bullet points.
    
    Data: ${JSON.stringify(data)}`
    }
  ];

  if (fileData) {
    parts.push({
      inlineData: {
        data: fileData.data.split(',')[1] || fileData.data,
        mimeType: fileData.mimeType
      }
    });
    parts[0].text += "\n\nAlso analyze the attached file/image for any relevant OSINT clues (metadata, visible text, recognizable entities, etc.).";
  }

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: { parts },
    config: {
      systemInstruction: "You are a senior cybersecurity OSINT analyst. Provide professional, technical, and actionable intelligence reports. Focus on facts and potential risks. Do not speculate without evidence.",
    }
  });
  
  return response.text;
};

export const webSearchOSINT = async (query: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Perform an OSINT investigation on: ${query}. 
    Look for social media profiles, domain history, email mentions, and public records.`,
    config: {
      tools: [{ googleSearch: {} }],
    }
  });
  
  return {
    text: response.text,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};
