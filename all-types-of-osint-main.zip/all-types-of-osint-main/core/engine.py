import asyncio
import aiohttp
from typing import List, Dict
from urllib.parse import urlparse, urlunparse

DORK_TEMPLATES = {
    "email":    'site:linkedin.com OR site:hunter.io "{target}"',
    "domain":   'site:{target} -www inurl:admin OR inurl:login',
    "username": '"{target}" site:github.com OR site:twitter.com',
    "person":   '"{target}" (LinkedIn OR "contact" OR email)',
    "ip":       '"ip:{target}" site:shodan.io OR site:censys.io',
}

async def google_dorker(query: str, category: str, region: str):
    template = DORK_TEMPLATES.get(category, '"{query}"')
    dork = template.replace("{target}", query)
    # Mock implementation for demonstration
    await asyncio.sleep(0.5)
    return [{"source": "Google", "title": f"Result for {dork} in {region}", "url": "https://google.com"}]

async def yandex_search(query: str):
    await asyncio.sleep(0.5)
    return [{"source": "Yandex", "title": f"Russian result for {query}", "url": "https://yandex.ru"}]

async def baidu_search(query: str):
    await asyncio.sleep(0.5)
    return [{"source": "Baidu", "title": f"Chinese result for {query}", "url": "https://baidu.com"}]

def normalise_url(url: str) -> str:
    p = urlparse(url.lower().strip())
    # Strip tracking params, force https, strip trailing slash
    clean = p._replace(scheme="https", query="", fragment="")
    return urlunparse(clean).rstrip("/")

async def global_search(query: str, region: str = "ALL"):
    tasks = [
        google_dorker(query, "domain", region),
        yandex_search(f"{query} -site:google.com"),  # exclude cross-listing
        baidu_search(f'"{query}"'),                  # exact match on Baidu
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    seen, unique = set(), []
    for res in results:
        if not isinstance(res, list):
            continue
        for r in res:
            norm = normalise_url(r.get("url", ""))
            if norm not in seen:
                seen.add(norm)
                r["url_normalised"] = norm
                unique.append(r)
    return unique

if __name__ == "__main__":
    import json
    import sys
    query = sys.argv[1] if len(sys.argv) > 1 else "test"
    loop = asyncio.get_event_loop()
    results = loop.run_until_complete(global_search(query))
    print(json.dumps(results))
