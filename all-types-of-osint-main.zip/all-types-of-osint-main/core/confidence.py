SOURCE_TRUST = {
    "government_registry": 0.97,
    "official_company_reg": 0.95,
    "linkedin_verified":   0.88,
    "news_outlet":         0.75,
    "social_media":        0.60,
    "forum_blog":          0.35,
    "unknown":             0.20,
}

def score_result(result: dict) -> dict:
    source_type  = result.get("source_type", "unknown")
    base         = SOURCE_TRUST.get(source_type, 0.20)
    age_days     = result.get("age_days", 0)
    age_factor   = max(0.5, 1 - (age_days / 365) * 0.3)
    source_count = result.get("source_count", 1)

    # Stronger reward for 3+ corroborating sources
    if source_count >= 3:
        corroboration = min(1.15, 1 + (source_count - 1) * 0.10)
    else:
        corroboration = min(1.0,  1 + (source_count - 1) * 0.05)

    # Penalty if data contradicts another source
    if result.get("contradicted", False):
        corroboration *= 0.6

    confidence = round(base * age_factor * corroboration, 2)
    result["confidence"] = min(confidence, 0.99)  # never claim 100%
    result["grade"] = (
        "HIGH"   if confidence > 0.80 else
        "MEDIUM" if confidence > 0.50 else "LOW"
    )
    return result
