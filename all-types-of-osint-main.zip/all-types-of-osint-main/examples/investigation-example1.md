# Investigation Example: Username Correlation

**Target**: `johndoe123`

1. **Step 1**: Run `Sherlock` to find social media profiles.
   - Result: Found profiles on Twitter, GitHub, and Instagram.
2. **Step 2**: Analyze GitHub profile for email addresses.
   - Result: Found `john.doe@example.com` in a commit.
3. **Step 3**: Search `HaveIBeenPwned` for the email.
   - Result: Email was part of the 2019 LinkedIn breach.
4. **Step 4**: Correlate with LinkedIn profile.
   - Result: Confirmed target's professional identity.
