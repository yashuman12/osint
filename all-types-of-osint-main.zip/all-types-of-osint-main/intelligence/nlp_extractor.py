import spacy
from langdetect import detect

LANGUAGE_MODELS = {
    "en": "en_core_web_sm", # Using sm for efficiency in this environment
    "de": "de_core_news_sm",
    "fr": "fr_core_news_sm",
    "es": "es_core_news_sm",
}

def extract_global_entities(text: str):
    try:
        lang = detect(text)
    except:
        lang = "en"
    model_name = LANGUAGE_MODELS.get(lang, "en_core_web_sm")
    try:
        nlp = spacy.load(model_name)
    except:
        nlp = spacy.load("en_core_web_sm")
    doc = nlp(text)

    def dedup(items):
        seen, out = set(), []
        for item in items:
            key = item.lower().strip()
            if key not in seen:
                seen.add(key)
                out.append(item)
        return out

    return {
        "persons": dedup([e.text for e in doc.ents if e.label_ == "PERSON"]),
        "orgs":    dedup([e.text for e in doc.ents if e.label_ == "ORG"]),
        "places":  dedup([e.text for e in doc.ents if e.label_ == "GPE"]),
        "lang":    lang,
        "entity_count": len(doc.ents),
    }

if __name__ == "__main__":
    import json
    import sys
    text = sys.argv[1] if len(sys.argv) > 1 else "Apple is looking at buying U.K. startup for $1 billion. Tim Cook is happy."
    print(json.dumps(extract_global_entities(text)))
