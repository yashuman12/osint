import phonenumbers
from phonenumbers import geocoder, carrier, timezone

def analyze_phone_global(number_str: str):
    try:
        parsed = phonenumbers.parse(number_str, None)
        return {
            "valid":        phonenumbers.is_valid_number(parsed),
            "country":      geocoder.description_for_number(parsed, "en"),
            "carrier":      carrier.name_for_number(parsed, "en"),
            "timezones":    list(timezone.time_zones_for_number(parsed)),
            "country_code": parsed.country_code,
            "number_type":  phonenumbers.number_type(parsed),
            "intl_format":  phonenumbers.format_number(
                                parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
        }
    except Exception as e:
        return {"error": str(e), "valid": False}

if __name__ == "__main__":
    import json
    import sys
    number = sys.argv[1] if len(sys.argv) > 1 else "+14155552671"
    print(json.dumps(analyze_phone_global(number)))
