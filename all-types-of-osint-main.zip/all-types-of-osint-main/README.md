# All Types of OSINT Tools

A curated list of 100+ Open Source Intelligence tools used in cybersecurity investigations, threat intelligence, digital forensics, and reconnaissance.

![OSINT](https://img.shields.io/badge/Cybersecurity-OSINT-green)
![License](https://img.shields.io/badge/License-MIT-blue)

## 📌 Overview
This repository serves as a comprehensive guide and toolkit for Open Source Intelligence (OSINT). It categorizes over 100 powerful tools and provides automation scripts to streamline investigations.

## 📂 Categories
- [Username OSINT](categories/username-osint.md)
- [Email Intelligence](categories/email-osint.md)
- [Domain Intelligence](categories/domain-osint.md)
- [Social Media Intelligence](categories/social-media-osint.md)
- [Image OSINT](categories/image-osint.md)
- [Geolocation Intelligence](categories/geolocation-osint.md)
- [Breach Data Analysis](categories/breach-osint.md)
- [Dark Web Intelligence](categories/darkweb-osint.md)
- [People Search](categories/people-search.md)
- [Company Intelligence](categories/company-osint.md)

## 🛠 Automation Tools
- [SpiderFoot](https://www.spiderfoot.net/)
- [Recon-ng](https://github.com/lanmaster53/recon-ng)
- [theHarvester](https://github.com/laramies/theHarvester)
- [Amass](https://github.com/OWASP/Amass)

## 🔌 Integrated OSINT Engine & Query Sources

Aegis OSINT Suite integrates first-class query providers with confidence weighting, resilient retries, and local TTL response caching:

### 1. API-Based Threat & Asset Intelligence (Configured via `.env`)
- **ZoomEye** (`ZOOMEYE_API_KEY`): Cyberspace search engine for global host and port intelligence. (Get key: [https://www.zoomeye.hk](https://www.zoomeye.hk))
- **ONYPHE** (`ONYPHE_API_KEY`): Cyber Defense Search Engine for open ports, threat info, and vulnerabilities. (Get key: [https://www.onyphe.io](https://www.onyphe.io))
- **BinaryEdge** (`BINARYEDGE_API_KEY`): Internet scanning and threat intelligence data. (Get key: [https://app.binaryedge.io](https://app.binaryedge.io))
- **Netlas.io** (`NETLAS_API_KEY`): Technical OSINT search engine for domains and IP ranges. (Get key: [https://app.netlas.io](https://app.netlas.io))
- **Criminal IP** (`CRIMINALIP_API_KEY`): Threat intelligence search engine for malicious IP detection and scoring. (Get key: [https://www.criminalip.io](https://www.criminalip.io))
- **SecurityTrails** (`SECURITYTRAILS_API_KEY`): Passive DNS and historical DNS record intelligence. (Get key: [https://securitytrails.com](https://securitytrails.com))
- **OpenCorporates** (`OPENCORPORATES_API_TOKEN`): World's largest open database of corporate registry records. (Get token: [https://opencorporates.com](https://opencorporates.com))
- **Hunter.how** (`HUNTER_HOW_API_KEY`): Global internet asset mapping. (Get key: [https://hunter.how](https://hunter.how))

### 2. Keyless & Public Intelligence
- **crt.sh**: Certificate Transparency log aggregation and automated SAN subdomain discovery.
- **WhatsMyName**: Automated high-concurrency cross-platform username enumeration across 40+ sites using the community dataset.
- **ThreatMiner**: Passive DNS and SSL certificate intelligence.

### 3. CLI-Based Python OSINT Tools (Local Subprocesses)
- **Holehe**: Checks email account registrations across 120+ platforms (`pip install holehe`).
- **Maigret**: Advanced dossier builder across thousands of sites (`pip install maigret`).

## 🚀 Getting Started
1. Clone the repository.
2. Install dependencies: `npm install` and `pip install -r requirements.txt`.
3. Configure your API keys in `.env` (copied from `.env.example`).
4. Start the server: `npm run dev`.


## ⚖️ Legal & Ethical Use
Please refer to [Legal & Ethical Use](docs/legal-ethical-use.md) before conducting any investigations.
