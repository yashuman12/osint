import requests, sys, json

def scan_email(email: str):
    print(f"[*] Scanning: {email}\n")
    results = {}

    # 1. EmailRep (free, no key)
    r = requests.get(f"https://emailrep.io/{email}",
                     headers={"User-Agent": "aegis-osint/1.0"}, timeout=8)
    if r.ok:
        d = r.json()
        results["reputation"]     = d.get("reputation")
        results["suspicious"]     = d.get("suspicious")
        results["blacklisted"]    = d.get("details", {}).get("blacklisted")
        results["breach_count"]   = d.get("details", {}).get("breach_count")
        print(f"  Reputation : {results['reputation']}")
        print(f"  Suspicious : {results['suspicious']}")
        print(f"  Breaches   : {results['breach_count']}")

    # 2. Gravatar MD5 check (free, no key)
    import hashlib
    md5 = hashlib.md5(email.strip().lower().encode()).hexdigest()
    g = requests.get(f"https://www.gravatar.com/{md5}.json", timeout=5)
    results["has_gravatar"] = g.status_code == 200
    print(f"  Gravatar   : {'Yes' if results['has_gravatar'] else 'No'}")

    print(f"\n[+] Done. Raw: {json.dumps(results, indent=2)}")

if __name__ == "__main__":
    scan_email(sys.argv[1] if len(sys.argv) > 1 else "test@example.com")
