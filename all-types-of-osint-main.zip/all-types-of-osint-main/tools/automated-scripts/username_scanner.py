import asyncio, sys
import aiohttp

PLATFORMS = {
    "GitHub":     "https://github.com/{u}",
    "GitLab":     "https://gitlab.com/{u}",
    "Twitter/X":  "https://twitter.com/{u}",
    "Instagram":  "https://www.instagram.com/{u}/",
    "Reddit":     "https://www.reddit.com/user/{u}",
    "TikTok":     "https://www.tiktok.com/@{u}",
    "Twitch":     "https://www.twitch.tv/{u}",
    "YouTube":    "https://www.youtube.com/@{u}",
    "HackerNews": "https://news.ycombinator.com/user?id={u}",
    "Keybase":    "https://keybase.io/{u}",
    "Steam":      "https://steamcommunity.com/id/{u}",
}

async def check_platform(session, name, url_tpl, username):
    url = url_tpl.format(u=username)
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=5),
                               allow_redirects=True) as r:
            found = r.status == 200
            return (name, url, found)
    except:
        return (name, url, False)

async def scan_username(username: str):
    print(f"[*] Scanning: {username}\n")
    async with aiohttp.ClientSession(headers={"User-Agent":"Mozilla/5.0"}) as session:
        tasks = [check_platform(session, n, u, username) for n, u in PLATFORMS.items()]
        results = await asyncio.gather(*tasks)
    found = [(n, url) for n, url, ok in results if ok]
    print(f"  Found on {len(found)}/{len(PLATFORMS)} platforms:\n")
    for name, url in found:
        print(f"  [+] {name:<15} {url}")
    return found

if __name__ == "__main__":
    asyncio.run(scan_username(sys.argv[1] if len(sys.argv) > 1 else "test"))
