# Company Intelligence

Tools for corporate investigation.

- **Crunchbase**: Business information and insights.
- **OpenCorporates**: Largest open database of companies.
- **Glassdoor**: Company reviews and salaries.
- **LinkedIn**: Professional networking and company profiles.
- **Bloomberg**: Financial and business news.
- **ZoomInfo**: B2B database and sales intelligence.
- **D&B Hoovers**: Business data and analytics.
- **AngelList**: Startup and investor database.
- **PitchBook**: Private market data.
- **CB Insights**: Market intelligence and tech trends.
