# Breach Data & Leak Intelligence

Tools for data breach investigation.

- **HaveIBeenPwned**: Check if your email is in a data breach.
- **DeHashed**: Search leaked databases.
- **LeakCheck**: Breach search engine.
- **Snusbase**: Search leaked credentials.
- **BreachDirectory**: Search for leaked info.
- **IntelligenceX**: Search engine and archive for the darknet.
- **HudsonRock**: Cybercrime intelligence.
- **SpyCloud**: Account takeover prevention.
- **LeakPeek**: Search for leaked data.
- **WeLeakInfo**: Historical breach data search.
