# Username OSINT Tools

Tools for finding accounts across platforms.

- **Sherlock**: Hunt down social media accounts by username across social networks.
- **Maigret**: Collect a dossier on a person by username from a huge number of sites.
- **WhatsMyName**: Check for usernames on many websites.
- **Namechk**: Check if your desired username or domain name is available.
- **Namecheckup**: Username and domain search tool.
- **SocialCatfish**: Reverse search for social media profiles.
- **UserSearch**: Find people by username or email.
- **CheckUsernames**: Check username availability on 160+ social networks.
- **InstantUsername**: Search usernames on 100+ social media sites.
- **KnowEm**: Search over 500 popular social networks.
