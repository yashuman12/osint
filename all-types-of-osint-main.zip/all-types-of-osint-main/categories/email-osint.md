# Email OSINT Tools

Tools to investigate email ownership and activity.

- **Hunter.io**: Find professional email addresses in seconds.
- **EmailRep**: Email reputation and risk assessment.
- **DeHashed**: View leaked credentials and breach data.
- **LeakCheck**: Check if your email has been leaked.
- **EmailHippo**: Email address verification.
- **That’s Them**: Reverse email lookup.
- **VerifyEmailAddress**: Free email verification tool.
- **MailTester**: Check if an email address exists.
- **ProtonMail Email Checker**: Verify ProtonMail accounts.
- **VoilaNorbert**: Find anyone's email address.
