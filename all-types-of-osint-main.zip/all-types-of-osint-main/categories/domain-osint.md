# Domain & Website Intelligence

Tools for domain ownership, DNS, and infrastructure.

- **WHOIS Lookup**: Find domain registration information.
- **DNSDumpster**: DNS reconnaissance and search.
- **SecurityTrails**: Historical DNS and domain data.
- **ViewDNS**: Multiple DNS and domain tools.
- **Shodan**: Search engine for Internet-connected devices.
- **Censys**: Search engine for Internet-connected hosts and networks.
- **BuiltWith**: Identify technologies used on a website.
- **Netcraft**: Internet security and research.
- **VirusTotal**: Analyze files and URLs for threats.
- **PassiveTotal**: Threat infrastructure analysis.
