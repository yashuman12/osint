# Geolocation OSINT Tools

Tools for location intelligence.

- **Google Earth**: Detailed satellite imagery.
- **Google Maps**: Mapping and street view.
- **OpenStreetMap**: Community-driven map data.
- **Mapillary**: Street-level imagery platform.
- **Wikimapia**: Open-content collaborative map.
- **Sentinel Hub**: Satellite imagery browser.
- **SunCalc**: Sun position and shadows.
- **GeoGuessr**: Geolocation guessing game (useful for training).
- **FlightRadar24**: Live flight tracking.
- **MarineTraffic**: Live ship tracking.
