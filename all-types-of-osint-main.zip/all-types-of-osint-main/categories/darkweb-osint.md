# Dark Web Intelligence

Tools for dark web monitoring.

- **Torch Search**: One of the oldest search engines on the Tor network.
- **Ahmia**: Search engine for the Tor network.
- **DarkSearch**: First real-time search engine for the dark web.
- **OnionScan**: Security tool for dark web services.
- **Recon-ng**: Full-featured reconnaissance framework.
- **Maltego**: Interactive data mining and link analysis.
- **DarkOwl**: Dark web data provider.
- **OnionLand**: Search engine for hidden services.
- **Torscan**: Scanner for hidden services.
- **Phobos**: Dark web search engine.
